function likeButton1(){
    var countNum = document.querySelector("#firstBox");
    countNum.innerText= (parseInt(countNum.innerText)+1)
}

function likeButton2(){
    var countNum = document.querySelector("#secondBox");
    countNum.innerText= (parseInt(countNum.innerText)+1)
}

function likeButton3(){
    var countNum = document.querySelector("#thirdBox");
    countNum.innerText= (parseInt(countNum.innerText)+1)
}